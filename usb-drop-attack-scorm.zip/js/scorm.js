/* Minimal SCORM 1.2 wrapper with a local-development fallback. */
var SCORM = (function () {
  var api = null, mode = 'none', finished = false, KEY = 'usbdrop_scorm12_dev';
  var store = {}, memOnly = false;

  function findAPI(w) {
    var n = 0;
    try {
      while (w && !w.API && w.parent && w.parent !== w && n < 12) { w = w.parent; n++; }
      return (w && w.API) ? w.API : null;
    } catch (e) { return null; }
  }
  function locate() {
    var a = findAPI(window);
    if (!a) { try { if (window.opener) { a = findAPI(window.opener); } } catch (e) {} }
    return a;
  }
  function persist() {
    if (memOnly) return;
    try { window.localStorage.setItem(KEY, JSON.stringify(store)); } catch (e) { memOnly = true; }
  }
  function loadLocal() {
    try { store = JSON.parse(window.localStorage.getItem(KEY) || '{}') || {}; } catch (e) { store = {}; memOnly = true; }
    if (!store['cmi.core.lesson_status']) store['cmi.core.lesson_status'] = 'not attempted';
  }

  return {
    init: function () {
      api = locate();
      if (api) {
        var ok = false;
        try { ok = String(api.LMSInitialize('')) === 'true'; } catch (e) { ok = false; }
        if (ok) { mode = 'lms'; return true; }
        api = null;
      }
      mode = 'local'; loadLocal(); return true;
    },
    get: function (k) {
      if (mode === 'lms') { try { return String(api.LMSGetValue(k)); } catch (e) { return ''; } }
      return store[k] === undefined ? '' : String(store[k]);
    },
    set: function (k, v) {
      if (mode === 'lms') { try { return String(api.LMSSetValue(k, String(v))) === 'true'; } catch (e) { return false; } }
      store[k] = String(v); return true;
    },
    commit: function () {
      if (mode === 'lms') { try { return String(api.LMSCommit('')) === 'true'; } catch (e) { return false; } }
      persist(); return true;
    },
    finish: function () {
      if (finished) return true; finished = true;
      if (mode === 'lms') { try { return String(api.LMSFinish('')) === 'true'; } catch (e) { return false; } }
      persist(); return true;
    },
    reopen: function () { finished = false; },
    mode: function () { return mode; }
  };
})();
